# Google Map mask
Small app which demonstrates how to create a circle hole for specified location.

If you want to build this project on your machine, don't forget to put your `app/google-map-key.properties` file with Google Maps key. You can also install a [sample.apk](https://github.com/AntonyGolovin/Google-Map-mask/blob/master/app/sample.apk).

This repository was created for answer to [this](http://stackoverflow.com/questions/39124706/android-google-maps-polygon-add-circle-hole) question. 

![Screenshot](art/screenshot.png)  
